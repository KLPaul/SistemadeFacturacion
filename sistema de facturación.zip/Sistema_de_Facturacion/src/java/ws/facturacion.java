/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package ws;

import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.clasificacion;
import modelo.factura;
import modelo.item_factura;
import modelo.persona;
import modelo.producto;
import modelo.proveedores;
import modelo.tipo_pago;
import modelo.usuario;
import java.util.Date;
import modelo.competencia;
import modelo.rol;
import modelo.usuario_persona;

/**
 *
 * @author Usuario
 */
@WebService(serviceName = "facturacion")
public class facturacion {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
        
    }
    
private ArrayList<usuario> bd_tabla_listapersona= new ArrayList<>();
private ArrayList<persona> bd_tabla_listausuario= new ArrayList<>();
private ArrayList<usuario_persona> bd_tabla_usuariopersona= new ArrayList<>();
private ArrayList<usuario> bd_tabla_usuario= new ArrayList<>();

private ArrayList<factura> bd_tabla_listaTipoPago= new ArrayList<>();
private ArrayList<factura> bd_tabla_listaPersonas= new ArrayList<>();
     private ArrayList<producto> bd_tabla_listaClasificacion= new ArrayList<>(); 
     private ArrayList<producto> bd_tabla_proveedor= new ArrayList<>(); 
     private ArrayList<item_factura> bd_tabla_listafactura= new ArrayList<>();
     private ArrayList<item_factura> bd_listaproducto= new ArrayList<>();
    
     public void cargarDatos() {
         
// Creamos los tipos de pago
        tipo_pago tp1 = new tipo_pago(1, "EFECTIVO", "Pago mediante monedas o billetes");
        tipo_pago tp2 = new tipo_pago(2, "TRANSFERENCIA BANCARIA", "El dinero se transfiere electrónicamente de una cuenta bancaria");
        tipo_pago tp3 = new tipo_pago(3, "TERJETA DEBITO", " El dinero se retira directamente de la cuenta del titular");
       
        // Creamos las personas
        persona pr1 = new persona(1, "JULIO", "JARAMILLO", "0150266387", "0998814976", "jj@gmail.com");
        persona pr2 = new persona(2, "MANUEL", "PAREDES", "015026999", "0998812221", "mn@gmail.com");
        persona pr3 = new persona(3, "MARIA", "ORTIZ", "0150261123", "0998835421", "mO@gmail.com");
        
        rol r1 = new rol(1,"ADMNISTRADOR", true);
        rol r2 = new rol(2,"SEGURIDAD", false);
        rol r3 = new rol(3,"GESTION", true);
        
        competencia cp1= new competencia(1,"ABISMAL","Enfocada en procesos");
        competencia cp2= new competencia(2,"NO ABISMAL","No enfocada en procesos");
        competencia cp3= new competencia(1,"ADJUDICATURA","Enfocada en ejecucuiones");
        
        
        proveedores pv1 = new proveedores(1,"232","3432","Canada","as@gmail.com","Dolar Canadiense");
        proveedores pv2 = new proveedores(2,"543","7564","Ecuador","ec@gmail.com","Dolar");
        proveedores pv3 = new proveedores(3,"645","8233","Argentina","sae@gmail.com","Peso");
        
        clasificacion cl1 = new clasificacion(1,"Maxima");
        clasificacion cl2 = new clasificacion(2,"Minima");
        clasificacion cl3 = new clasificacion(3,"Media");


        usuario u1 = new usuario(1, "admin", "1234");
        bd_tabla_usuariopersona = new ArrayList<>();
        bd_tabla_usuariopersona.add(new usuario_persona(1, 1));
        bd_tabla_usuariopersona.add(new usuario_persona(1, 2));
        u1.setListapersona(bd_tabla_listausuario);
        
 
  
        bd_tabla_usuario.add(u1); 
    }
     
     
     @WebMethod(operationName = "validarDatos")
    public ArrayList<persona> credenciales(String usuario, String password) {
        cargarDatos();
        for (usuario us : bd_tabla_listapersona) {
            if (usuario.equals(us.getUser()) && password.equals(us.getPassword())) {
                return us.getListapersona();
            }
        }
        return null;
    }    

    
}
