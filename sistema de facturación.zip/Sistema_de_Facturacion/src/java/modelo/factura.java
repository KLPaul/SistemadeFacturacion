/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Usuario
 */
public class factura {
    
     private int id_factura;
    private String ruc;
    private int id_persona;
    private Date fecha;
    private int id_tipo_pago;
    private double descuento;
    private double total;
    
    private ArrayList<tipo_pago> listaTipoPago;
    private ArrayList<persona> listapersonas;
    
    public factura() {
    }

    public factura(int id_factura, String ruc, int id_persona, Date fecha, int id_tipo_pago, double descuento, double total, ArrayList<tipo_pago> listaTipoPago, ArrayList<persona> listapersonas) {
        this.id_factura = id_factura;
        this.ruc = ruc;
        this.id_persona = id_persona;
        this.fecha = fecha;
        this.id_tipo_pago = id_tipo_pago;
        this.descuento = descuento;
        this.total = total;
        this.listaTipoPago = listaTipoPago;
        this.listapersonas = listapersonas;
    }

    public int getId_factura() {
        return id_factura;
    }

    public void setId_factura(int id_factura) {
        this.id_factura = id_factura;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public int getId_persona() {
        return id_persona;
    }

    public void setId_persona(int id_persona) {
        this.id_persona = id_persona;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getId_tipo_pago() {
        return id_tipo_pago;
    }

    public void setId_tipo_pago(int id_tipo_pago) {
        this.id_tipo_pago = id_tipo_pago;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public ArrayList<tipo_pago> getListaTipoPago() {
        return listaTipoPago;
    }

    public void setListaTipoPago(ArrayList<tipo_pago> listaTipoPago) {
        this.listaTipoPago = listaTipoPago;
    }
    
       public ArrayList<persona> getListaPersona() {
        return listapersonas;
    }

    public void setListalistapersona(ArrayList<persona> listapersonas) {
        this.listapersonas = listapersonas;
    }
    
}
