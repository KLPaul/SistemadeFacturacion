/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class producto {
    private int id_producto;
    private int stock;
    private Double precio_unitario;
    private String unidad;
    private int id_clasificación;
    private int id_proveedor;
    private Boolean iva;
    
    private ArrayList<clasificacion>listaclasificacion;
    private ArrayList<proveedores>listaproveedor;
    

    public producto() {
        listaclasificacion = new ArrayList<>();
        listaproveedor = new ArrayList<>();
    }
        
    public producto(int id_producto, int stock, Double precio_unitario, String unidad, int id_clasificación, int id_proveedor, Boolean iva, ArrayList<clasificacion>listaclasificacion, ArrayList<proveedores>listaproveedor) {
        this.id_producto = id_producto;
        this.stock = stock;
        this.precio_unitario = precio_unitario;
        this.unidad = unidad;
        this.id_clasificación = id_clasificación;
        this.id_proveedor = id_proveedor;
        this.iva = iva;
        this.listaclasificacion=listaclasificacion;
        this.listaproveedor=listaproveedor;
   }
     
    public int getId_producto() {
        return id_producto;
    }

    public void setId_producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Double getPrecio_unitario() {
        return precio_unitario;
    }

    public void setPrecio_unitario(Double precio_unitario) {
        this.precio_unitario = precio_unitario;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    public int getId_clasificación() {
        return id_clasificación;
    }

    public void setId_clasificación(int id_clasificación) {
        this.id_clasificación = id_clasificación;
    }

    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    public Boolean getIva() {
        return iva;
    }

    public void setIva(Boolean iva) {
        this.iva = iva;
    }
    
      public ArrayList<clasificacion> getListaclasificacion() {
        return listaclasificacion;
    }

    public void setListafactura(ArrayList<clasificacion> listaclasificacion) {
        this.listaclasificacion = listaclasificacion;
    }
    
    public ArrayList<proveedores> getListaproveedor() {
        return listaproveedor;
    }

    public void setListaproveedor(ArrayList<proveedores> listaproveedor) {
        this.listaproveedor = listaproveedor;
    }
    
}
